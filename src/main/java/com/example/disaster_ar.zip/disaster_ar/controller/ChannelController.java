package com.example.disaster_ar.controller;

import com.example.disaster_ar.domain.School;
import com.example.disaster_ar.service.ChannelService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@Tag(name = "Channel")
@RestController
@RequestMapping("/api/channels")
@RequiredArgsConstructor
public class ChannelController {

    private final ChannelService channelService;

    @Value("${file.upload.dir:uploads/maps}")
    private String uploadDir;

    @Operation(summary = "학교 채널 생성(지도 이미지 선택 가능)")
    @PostMapping(consumes = {"multipart/form-data"})
    public ResponseEntity<School> createChannel(
            @RequestPart("schoolName") String schoolName,
            @RequestPart(value = "mapImage", required = false) MultipartFile mapImage
    ) {
        return ResponseEntity.ok(channelService.createChannel(schoolName, mapImage, uploadDir));
    }

    @Operation(summary = "방 코드 조회")
    @GetMapping("/{schoolId}/room-code")
    public ResponseEntity<String> getRoomCode(@PathVariable String schoolId) {
        return ResponseEntity.ok(channelService.getRoomCode(schoolId));
    }

    @Operation(summary = "방 코드 재발급")
    @PutMapping("/{schoolId}/room-code")
    public ResponseEntity<String> regenerateRoomCode(@PathVariable String schoolId) {
        return ResponseEntity.ok(channelService.regenerateRoomCode(schoolId));
    }
}
