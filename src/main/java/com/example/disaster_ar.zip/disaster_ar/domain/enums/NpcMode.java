package com.example.disaster_ar.domain.enums;

public enum NpcMode {
    AUTO,
    MANUAL
}
