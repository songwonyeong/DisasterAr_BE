package com.example.disaster_ar.domain.enums;

public enum TeamMode {
    AUTO,
    MANUAL
}
