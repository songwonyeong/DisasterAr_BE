package com.example.disaster_ar.domain;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDateTime;

import com.example.disaster_ar.domain.enums.ScenarioType;
import com.example.disaster_ar.domain.enums.TriggerMode;
import com.example.disaster_ar.domain.enums.TeamMode;
import com.example.disaster_ar.domain.enums.NpcMode;

@Getter
@Setter   // ✅ get/set 모두 자동 생성
@NoArgsConstructor
@Entity
@Table(name = "scenarios")
public class Scenario {
    @Id private String id;

    @Column(name="classroom_id") private String classroomId;

    @Enumerated(EnumType.STRING) private ScenarioType scenarioType;
    @Enumerated(EnumType.STRING) private TriggerMode triggerMode;
    @Enumerated(EnumType.STRING) private TeamMode teamMode;
    @Enumerated(EnumType.STRING) private NpcMode npcMode;

    private String location;
    private Integer intensity;
    @Column(name="train_time") private Integer trainTime;

    // JSON 컬럼 — 필드명은 단순히 teamAssignment / npcPositions 로 둡니다.
    @Column(columnDefinition = "json") private String teamAssignment;
    @Column(columnDefinition = "json") private String npcPositions;

    @Column(name="participant_count") private Integer participantCount;
    @Column(name="created_time") private LocalDateTime createdTime;
}