package com.example.disaster_ar.domain.enums;

public enum ScenarioType {
    FIRE,
    EARTHQUAKE,
    CHEMICAL,
    OTHER
}
