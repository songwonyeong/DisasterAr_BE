package com.example.disaster_ar.domain.enums;

public enum TriggerMode {
    AUTO,
    MANUAL
}
