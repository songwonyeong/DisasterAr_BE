package com.example.disaster_ar.domain;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.UuidGenerator;

@Entity
@Table(
        name = "schools",
        uniqueConstraints = {
                @UniqueConstraint(name = "uk_schools_school_name", columnNames = "school_name")
        }
)
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor @Builder
public class School {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID) // ✅ Hibernate 6 / Spring Boot 3 권장
    @Column(length = 36)                            // UUID 길이 36
    private String id;

    @Column(name = "school_name", nullable = false, length = 255)
    private String schoolName;

    @Column(name = "map_file", length = 255)
    private String mapFile;

    @Column(name = "access_code", length = 255)
    private String accessCode;

    // 양방향이 필요하면 나중에 열자 (지금은 validate 통과 우선)
    // @OneToMany(mappedBy = "school")
    // private List<User> users = new ArrayList<>();
}
