package com.example.disaster_ar.domain.v4.enums;

public enum QuizResultStatus {
    CORRECT, FAILED
}
