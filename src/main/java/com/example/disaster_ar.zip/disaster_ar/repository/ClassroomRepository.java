package com.example.disaster_ar.repository;

import com.example.disaster_ar.domain.Classroom;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClassroomRepository extends JpaRepository<Classroom, String> { }
