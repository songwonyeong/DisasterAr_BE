package com.example.disaster_ar;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DisasterArApplication {

	public static void main(String[] args) {
		SpringApplication.run(DisasterArApplication.class, args);
	}

}
