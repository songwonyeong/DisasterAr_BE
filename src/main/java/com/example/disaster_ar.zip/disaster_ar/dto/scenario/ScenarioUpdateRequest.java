package com.example.disaster_ar.dto.scenario;

import lombok.*;

@Getter
@Setter
public class ScenarioUpdateRequest {
    private String scenarioId;     // 업데이트 대상
    private String scenarioType;   // 선택적
    private String triggerMode;
    private String teamMode;
    private String npcMode;
    private String location;
    private Integer intensity;
    private Integer trainTime;
    private String teamAssignment; // JSON 문자열
    private String npcPositions;   // JSON 문자열
    private Integer participantCount;
}
