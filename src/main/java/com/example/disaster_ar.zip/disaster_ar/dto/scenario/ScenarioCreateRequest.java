package com.example.disaster_ar.dto.scenario;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ScenarioCreateRequest {

    private String classroomId;
    private String scenarioType;  // "FIRE" 등
    private String triggerMode;   // "AUTO"/"MANUAL"
    private String teamMode;
    private String npcMode;
    private String location;
    private Integer intensity;
    private Integer trainTime;
    private String teamAssignment; // JSON 문자열
    private String npcPositions;   // JSON 문자열
    private Integer participantCount;
}
