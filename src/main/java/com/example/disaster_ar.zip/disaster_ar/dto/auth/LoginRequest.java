package com.example.disaster_ar.dto.auth;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class LoginRequest {
    @Email @NotBlank
    private String email;
    @NotBlank
    private String password;

    // getters/setters
}
