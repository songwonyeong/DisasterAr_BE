package com.example.disaster_ar.dto.school;

import org.springframework.web.multipart.MultipartFile;

public class ChannelCreateRequest {
    private String schoolName;
    private MultipartFile mapImage; // optional

    // getters/setters
}
