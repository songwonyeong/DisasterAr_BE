package com.example.disaster_ar.dto.scenario;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter @Setter
public class ScenarioResponse {
    private String id;
    private String classroomId;

    // enum 값은 문자열로 내려줌
    private String scenarioType;   // FIRE, EARTHQUAKE ...
    private String triggerMode;    // AUTO, MANUAL
    private String teamMode;       // AUTO, MANUAL
    private String npcMode;        // AUTO, MANUAL

    private String location;
    private Integer intensity;
    private Integer trainTime;

    // JSON 문자열 그대로 노출
    private String teamAssignmentJson;
    private String npcPositionsJson;

    private Integer participantCount;
    private LocalDateTime createdTime;
}
