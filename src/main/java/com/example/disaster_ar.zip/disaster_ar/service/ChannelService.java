package com.example.disaster_ar.service;

import com.example.disaster_ar.domain.School;
import com.example.disaster_ar.repository.SchoolRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.UUID;

@Service
@RequiredArgsConstructor
public class ChannelService {
    private final SchoolRepository schoolRepository;

    public School createChannel(String schoolName, MultipartFile mapImage, String uploadDir) {
        School school = schoolRepository.findBySchoolName(schoolName).orElseGet(() -> {
            School s = new School();
            s.setId(UUID.randomUUID().toString());
            s.setSchoolName(schoolName);
            s.setAccessCode(generateAccessCode());
            return s;
        });

        if (mapImage != null && !mapImage.isEmpty()) {
            try {
                Path dir = Paths.get(uploadDir).toAbsolutePath().normalize();
                Files.createDirectories(dir);
                String filename = school.getId() + "_" + mapImage.getOriginalFilename();
                Path target = dir.resolve(filename);
                mapImage.transferTo(target.toFile());
                school.setMapFile(filename);
            } catch (Exception e) {
                throw new RuntimeException("지도 파일 저장 실패", e);
            }
        }

        return schoolRepository.save(school);
    }

    public String getRoomCode(String schoolId) {
        School school = schoolRepository.findById(schoolId)
                .orElseThrow(() -> new IllegalArgumentException("학교가 존재하지 않습니다."));
        return school.getAccessCode();
    }

    public String regenerateRoomCode(String schoolId) {
        School school = schoolRepository.findById(schoolId)
                .orElseThrow(() -> new IllegalArgumentException("학교가 존재하지 않습니다."));
        school.setAccessCode(generateAccessCode());
        schoolRepository.save(school);
        return school.getAccessCode();
    }

    private String generateAccessCode() {
        return UUID.randomUUID().toString().substring(0, 6).toUpperCase();
    }
}
